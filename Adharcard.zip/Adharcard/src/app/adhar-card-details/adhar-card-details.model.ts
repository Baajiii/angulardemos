export class AdharModel{
    name:string = '';
    email: string = '';
    mobileNumber : string = '';
    gender : string = '';
    address : string = '';
    dob : string = '';
    issueDate : string = '';
    status : string ='';
    adharCardId:number = 0;
}