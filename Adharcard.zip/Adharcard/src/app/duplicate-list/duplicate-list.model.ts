export class DuplicateModel{
    name:string = '';
    id:number = 0;
    adharCardId:string = '';
}